
import javax.swing.*;

public class eje1 {

    public static void main(String[] args) {
        JFrame frame = new JFrame("ejercicio 1");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        JButton button1 = new JButton("Presionar");
        frame.getContentPane().add(button1);
        frame.setVisible(true);
    }
}
