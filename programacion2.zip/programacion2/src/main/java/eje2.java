
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class eje2 {

    public static void main(String[] args) {

        JFrame frame = new JFrame("ejercicio 2");
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);

        frame.setVisible(true);
    }

    private static void placeComponents(JPanel panel) {

        panel.setLayout(null);

        JLabel userLabel = new JLabel("Hola mundo");
        userLabel.setBounds(10, 10, 80, 25);
        panel.add(userLabel);

    }

}
